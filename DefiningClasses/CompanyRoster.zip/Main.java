import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);



        int n = Integer.parseInt(scanner.nextLine());

        HashMap<String,Departament>departaments = new HashMap<>();

        while(n-->0) {
            String[] tokens = scanner.nextLine().split("\\s+");

            String departmentName = tokens[3];

            Employee emp = new Employee(tokens[0], Double.parseDouble(tokens[1]), tokens[2]);

            if (tokens.length == 5) {
                if (Character.isDigit(tokens[4].charAt(0))) {
                    emp.setAge(Integer.parseInt(tokens[4]));
                } else {
                    emp.setEmail(tokens[4]);
                }

            }

            if (tokens.length == 6) {
                emp.setEmail(tokens[4]);
                emp.setAge(Integer.parseInt(tokens[5]));
            }

            if (!departaments.containsKey(departmentName)) {
                departaments.put(departmentName, new Departament());
            }
            departaments.get(departmentName).addEmployee(emp);

        }
        Map.Entry<String, Departament> maxSalaryEntry = departaments.entrySet().stream()
                .sorted((f, s) -> Double.compare(s.getValue().getAverageSalary(),f.getValue().getAverageSalary())).findFirst()
                .get();

        System.out.println("Highest Average Salary: "+ maxSalaryEntry.getKey());
        maxSalaryEntry.getValue().getEmployees()
                .sort((e1,e2)->Double.compare(e2.getSalary(),e1.getSalary()));
        maxSalaryEntry.getValue().getEmployees()
                .forEach(emp-> System.out.println(String.format("%s %.2f %s %d"
                        ,emp.getName(),emp.getSalary(),
                        emp.getEmail(),emp.getAge())));
    }

}
