import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                  new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());

        LinkedHashMap<String,Car> cars = new LinkedHashMap<>();

        while(n-->0){
            String [] tokens = reader.readLine().split("\\s+");
            String model = tokens[0];
            int engineSpeed = Integer.parseInt(tokens[1]);
            int enginePower = Integer.parseInt(tokens[2]);
            int cargoWeight = Integer.parseInt(tokens[3]);
            String cargoType = tokens[4];
            double tyreOnePressure = Double.parseDouble(tokens[5]);
            int tyreOneAge = Integer.parseInt(tokens[6]);
            double tyreTwoPressure = Double.parseDouble(tokens[7]);
            int tyreTwoAge = Integer.parseInt(tokens[8]);
            double tyreThreePressure = Double.parseDouble(tokens[9]);
            int tyreThreeAge = Integer.parseInt(tokens[10]);
            double tyreFourPressure = Double.parseDouble(tokens[11]);
            int tyreFourAge = Integer.parseInt(tokens[12]);

            Engine engine = new Engine(engineSpeed,enginePower);
            Tyre tyre = new Tyre(tyreOnePressure,tyreTwoPressure,tyreThreePressure,tyreFourPressure,
                    tyreOneAge,tyreTwoAge,tyreThreeAge,tyreFourAge);
            Cargo cargo = new Cargo(cargoWeight,cargoType);

            Car car = new Car(model,engine,tyre,cargo);

            cars.put(model,car);
        }

        String command = reader.readLine();
        if(command.equals("fragile")){
                cars.entrySet().stream().forEach(e->{
                    if(e.getValue().getCargo().getCargoType().equals("fragile")&&
                            (e.getValue().getTyre().getTyreOnePressure()<1)||(e.getValue().getTyre().getTyreTwoPressure()<1)
                    ||(e.getValue().getTyre().getTyreThreePressure()<1)||(e.getValue().getTyre().getTyreFourPressure()<1)){
                        System.out.println(e.getKey());
                    }
                });
        }else {
            cars.entrySet().stream().forEach(e->{
                if((e.getValue().getCargo().getCargoType().equals("flamable")&&
                        (e.getValue().getEngine().getEnginePower()>250))){
                    System.out.println(e.getKey());
                }
            });
        }


    }

}
