public class Car {
    private String model;
    private Engine engine;
    private Tyre tyre;
    private Cargo cargo;

    public Car(String model, Engine engine, Tyre tyre, Cargo cargo) {
        this.model = model;
        this.engine = engine;
        this.tyre = tyre;
        this.cargo = cargo;
    }

    public Tyre getTyre() {
        return tyre;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public Engine getEngine() {
        return engine;
    }
}
