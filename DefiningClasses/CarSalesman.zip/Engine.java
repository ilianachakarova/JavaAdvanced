public class Engine {
    private String modelEngine;
    private int power;
    private  int displacement;
    private String efficiency;

    public Engine(String modelEngine, int power) {
        this.modelEngine = modelEngine;
        this.power = power;
        this.displacement = -1;
        this.efficiency = "n/a";
    }

    public void setDisplacement(int displacement) {
        this.displacement = displacement;
    }

    public void setEfficiency(String efficiency) {
        this.efficiency = efficiency;
    }

    public String getModelEngine() {
        return modelEngine;
    }

    public int getPower() {
        return power;
    }

    public int getDisplacement() {
        return displacement;
    }

    public String getEfficiency() {
        return efficiency;
    }
}
