import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                  new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());
        String modelEngine;
        int power;
        int displacement;
        String efficiency;

        Map <String, Engine> engines =  new LinkedHashMap<>();
        List<Car> cars = new ArrayList<>();

        while(n-->0){
            String [] tokens = reader.readLine().split("\\s+");
            if(tokens.length == 2){
                modelEngine = tokens[0];
                power = Integer.parseInt(tokens[1]);
                Engine engine = new Engine(modelEngine,power);
                engines.put(modelEngine,engine);
            }else if(tokens.length == 3){
                modelEngine = tokens[0];
                power = Integer.parseInt(tokens[1]);
                Engine engine = new Engine(modelEngine,power);
                if(Character.isDigit(tokens[2].charAt(0))){
                    displacement = Integer.parseInt(tokens[2]);
                    engine.setDisplacement(displacement);
                }else {
                    efficiency = tokens[2];
                    engine.setEfficiency(efficiency);
                }

                engines.put(modelEngine,engine);
            }else {
                modelEngine = tokens[0];
                power = Integer.parseInt(tokens[1]);
                displacement = Integer.parseInt(tokens[2]);
                efficiency = tokens[3];
                Engine engine = new Engine(modelEngine,power);
                engines.put(modelEngine,engine);
                engine.setDisplacement(displacement);
                engine.setEfficiency(efficiency);
                engines.put(modelEngine,engine);

            }

        }

        int m = Integer.parseInt(reader.readLine());

        while(m-->0){
            String [] tokens = reader.readLine().split("\\s+");
            if(tokens.length == 2){
                String model = tokens[0];
                String engineModel = tokens[1];
                Car car =  new Car(model,engines.get(engineModel));
                cars.add(car);
            }else if(tokens.length == 3){
                String model = tokens[0];
                String engineModel = tokens[1];
                Car car =  new Car(model,engines.get(engineModel));
                if(Character.isDigit(tokens[2].charAt(0))){
                    int weight = Integer.parseInt(tokens[2]);
                    car.setWeight(weight);
                }else {
                    String color = tokens[2];
                    car.setColor(color);
                }
                cars.add(car);
            }else {
                String model = tokens[0];
                String engineModel = tokens[1];
                int weight = Integer.parseInt(tokens[2]);
                String color = tokens[3];
                Car car =  new Car(model,engines.get(engineModel));
                car.setWeight(weight);
                car.setColor(color);
                cars.add(car);
            }

            }

        cars.stream().forEach(car->{
            System.out.println(car.getModel()+":");
            System.out.println(car.getEngine().getModelEngine()+":");
            System.out.println("Power: "+ car.getEngine().getPower());
            if(car.getEngine().getDisplacement()==-1){
                System.out.println("Displacement: n/a");
            }else {
                System.out.println("Displacement: "+ car.getEngine().getDisplacement());
            }
            System.out.println("Efficiency: "+ car.getEngine().getEfficiency());
            if(car.getWeight() == -1){
                System.out.println("Weight: n/a");
            }else {
                System.out.println("Weight: "+ car.getWeight());
            }
            System.out.println("Color: "+ car.getColor());
        });

        }



}


