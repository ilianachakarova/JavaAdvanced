import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));

        Map<String,Trainer> trainerMap = new LinkedHashMap<>();

        String line = "";

        while(!"Tournament".equals(line = reader.readLine())){
            String [] tokens = line.split("\\s+");
            String trainerName = tokens[0];

            if(!trainerMap.containsKey(trainerName)){
                Trainer trainer = new Trainer(trainerName);
                trainerMap.put(trainerName,trainer);
            }
            Trainer trainer = trainerMap.get(trainerName);

            String pokemonName = tokens[1];
            String element = tokens[2];
            int health = Integer.parseInt(tokens[3]);

            Pokemon pokemon = new Pokemon(pokemonName,element,health);
            trainer.getPokemonList().add(pokemon);
        }

        String command = "";

        while(!"End".equals(command = reader.readLine())){
            for (Trainer trainer : trainerMap.values()) {
                String type = command;
                long count = trainer.getPokemonList().stream().filter(pokemon -> pokemon.getElement().equals(type)).count();

                boolean needsToBeRemoved = false;
                if(count>0){
                    trainer.setNumOfBadges(1);
                }else {
                    for (Pokemon pokemon : trainer.getPokemonList()) {
                        pokemon.setHealth(pokemon.getHealth()-10);
                        if(pokemon.getHealth()<=0){
                           needsToBeRemoved = true;
                        }
                    }
                    if(needsToBeRemoved){
                        trainer.getPokemonList().remove(trainer.getPokemonList().size()-1);
                    }
                }
            }

        }

        trainerMap.entrySet().stream()
                .sorted((e1,e2)->Integer.compare(e2.getValue().getNumOfBadges(),e1.getValue().getNumOfBadges()))
                .forEach(e-> System.out.println(String.format("%s %d %d",
                        e.getKey(),e.getValue().getNumOfBadges(),e.getValue().getPokemonList().size())));
    }

}


