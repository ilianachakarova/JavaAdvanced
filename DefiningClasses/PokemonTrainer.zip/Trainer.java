import java.util.ArrayList;
import java.util.List;

public class Trainer {
    private String trainerName;
    private int numOfBadges;
    private List<Pokemon>pokemonList;

    public Trainer(String trainerName) {
        this.trainerName = trainerName;
        this.numOfBadges = 0;
        this.pokemonList = new ArrayList<>();
    }

    public void addToList(Pokemon pokemon){
        this.pokemonList.add(pokemon);
    }

    public String getTrainerName() {
        return trainerName;
    }

    public int getNumOfBadges() {
        return numOfBadges;
    }

    public void setNumOfBadges(int numOfBadges) {
        this.numOfBadges += numOfBadges;
    }

    public List<Pokemon> getPokemonList() {
        return pokemonList;
    }
}
