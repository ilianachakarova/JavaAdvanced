import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));

        String input = "";

        Map<String,Person> people = new HashMap<>();

        while (!"End".equals(input = reader.readLine())) {
            String[] tokens = input.split("\\s+");

            String name = tokens[0];
            String command = tokens[1];

            if(!people.containsKey(name)){
                people.put(name,new Person(name));
            }

            switch (command) {
                case "company":
                    String companyName = tokens[2];
                    String department = tokens[3];
                    double salary = Double.parseDouble(tokens[4]);
                    Company company = new Company(companyName,department,salary);
                    people.get(name).setCompany(company);
                    break;
                case "pokemon":
                    String pokemonName = tokens[2];
                    String pokemonType = tokens[3];
                    Pokemon pokemon = new Pokemon(pokemonName,pokemonType);
                    people.get(name).addPokemons(pokemon);
                    break;
                case "parents":
                    String parentName = tokens[2];
                    String parentBirthdate = tokens[3];
                    Parent parent = new Parent(parentName,parentBirthdate);
                    people.get(name).addParent(parent);
                    break;
                case "children":
                    String childName = tokens[2];
                    String childBithdte = tokens[3];
                    Child child = new Child(childName,childBithdte);
                    people.get(name).addChild(child);
                    break;
                case "car":
                    String carModel = tokens[2];
                    int carSpeed = Integer.parseInt(tokens[3]);
                    Car car = new Car(carModel,carSpeed);
                    people.get(name).setCar(car);
                    break;
            }
        }

        String name = reader.readLine();

        System.out.println(name);
        System.out.println("Company:");
        if(people.get(name).getCompany().getSalary()!=0){
            System.out.println(people.get(name).getCompany().getCompanyName() + " "
                    +people.get(name).getCompany().getDepartment() + " "+
                    people.get(name).getCompany().getSalary());
        }
        System.out.println("Car:");
        if(people.get(name).getCar().getCarSpeed()!=0){
            System.out.println(people.get(name).getCar().getCarModel() + " "
                    +people.get(name).getCar().getCarSpeed());
        }
        System.out.println("Pokemon:");
        if(people.get(name).getPokemons().size()!=0){
            people.get(name).getPokemons().forEach(pokemon -> {
                System.out.println(pokemon.getPokemonName() + " " + pokemon.getPokemonType());
            });
        }
        System.out.println("Parents:");
        if(people.get(name).getParents().size()!=0){
            people.get(name).getParents().forEach(parent -> {
                System.out.println(parent.getParentName() + " " + parent.getParentBirthdate());
            });
        }
        System.out.println("Children:");
        if(people.get(name).getChildren().size()!=0){
            people.get(name).getChildren().stream().forEach(child -> {
                System.out.println(child.getChildName() + " " + child.getChildBirthdate());
            });
        }
    }

}


