public class Child {
    private String childName;
    private String childBirthdate;

    public Child(String childName, String childBirthdate) {
        this.childName = childName;
        this.childBirthdate = childBirthdate;
    }

    public String getChildName() {
        return childName;
    }

    public String getChildBirthdate() {
        return childBirthdate;
    }
}
