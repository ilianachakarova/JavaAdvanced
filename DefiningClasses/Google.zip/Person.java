import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private Company company;
    private List<Parent>parents;
    private List<Child>children;
    private List<Pokemon>pokemons;
    private Car car;


    public Person(String name) {
        this.name = name;
        this.setCompany(new Company());
        this.pokemons = new ArrayList<>();
        this.parents = new ArrayList<>();
        this.children = new ArrayList<>();
        this.car = new Car();
    }

    public void setCar(Car car){
        this.car = car;
    }

    public void addChild(Child child){
        this.children.add(child);
    }

    public void addParent(Parent parent){
        this.parents.add(parent);
    }

    public void addPokemons(Pokemon pokemon){
        this.pokemons.add(pokemon);
    }

    public void setCompany (Company company){
        this.company = company;
    }

    public String getName() {
        return name;
    }

    public Company getCompany() {
        return company;
    }

    public List<Parent> getParents() {
        return parents;
    }

    public List<Child> getChildren() {
        return children;
    }

    public List<Pokemon> getPokemons() {
        return pokemons;
    }

    public Car getCar() {
        return car;
    }
}
