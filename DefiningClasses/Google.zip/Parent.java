public class Parent {
    private String parentName;
    private String parentBirthdate;

    public Parent(String parentName, String parentBirthdate) {
        this.parentName = parentName;
        this.parentBirthdate = parentBirthdate;
    }

    public String getParentName() {
        return parentName;
    }

    public String getParentBirthdate() {
        return parentBirthdate;
    }
}
